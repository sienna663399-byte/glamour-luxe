import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import multer from "multer";
import path from "node:path";
import fs from "node:fs";
import { randomUUID } from "node:crypto";
import Stripe from "stripe";
import { PrismaClient, Role, VerificationStatus, PaymentStatus, BookingStatus } from "@prisma/client";
import { z } from "zod";

const prisma = new PrismaClient();
const app = express();
const PORT = Number(process.env.PORT || 4000);
const CLIENT_URL = process.env.CLIENT_URL || "http://localhost:5173";
const isProduction = process.env.NODE_ENV === "production";
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.warn("WARNING: JWT_SECRET should be a random string of at least 32 characters.");
}
const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;
const uploadDir = path.resolve(process.env.UPLOAD_DIR || "./private-uploads");
fs.mkdirSync(uploadDir, { recursive: true });

app.use(helmet());
app.use(cors({ origin: isProduction ? true : CLIENT_URL, credentials: true }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 250, standardHeaders: true, legacyHeaders: false }));
app.post("/api/payments/webhook", express.raw({ type: "application/json" }), async (req, res) => {
  if (!stripe || !process.env.STRIPE_WEBHOOK_SECRET) return res.status(503).send("Payments are not configured.");
  const sig = req.headers["stripe-signature"];
  if (!sig || Array.isArray(sig)) return res.status(400).send("Missing signature");
  let event: Stripe.Event;
  try { event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET); }
  catch { return res.status(400).send("Invalid webhook signature"); }
  try {
    if (event.type === "checkout.session.completed") {
      const session = event.data.object as Stripe.Checkout.Session;
      const payment = await prisma.payment.findFirst({ where: { stripeSessionId: session.id } });
      if (payment && session.payment_status === "paid" && payment.status !== PaymentStatus.SUCCEEDED) {
        const now = new Date();
        const base = payment.vipExpiresAt && payment.vipExpiresAt > now ? payment.vipExpiresAt : now;
        const expires = new Date(base);
        expires.setMonth(expires.getMonth() + payment.planMonths);
        await prisma.$transaction([
          prisma.payment.update({ where: { id: payment.id }, data: { status: PaymentStatus.SUCCEEDED, stripePaymentIntent: typeof session.payment_intent === "string" ? session.payment_intent : null, vipExpiresAt: expires } }),
          prisma.modelProfile.update({ where: { userId: payment.userId }, data: { isVip: true, vipExpiresAt: expires } }),
          prisma.auditLog.create({ data: { action: "VIP_PAYMENT_SUCCEEDED", entityType: "Payment", entityId: payment.id, metadata: { sessionId: session.id } } })
        ]);
      }
    } else if (event.type === "checkout.session.expired") {
      const session = event.data.object as Stripe.Checkout.Session;
      await prisma.payment.updateMany({ where: { stripeSessionId: session.id, status: PaymentStatus.PENDING }, data: { status: PaymentStatus.FAILED } });
    }
    res.json({ received: true });
  } catch (e) { console.error("Webhook processing failed", e); res.status(500).send("Webhook processing failed"); }
});
app.use(express.json({ limit: "1mb" }));

type AuthedRequest = express.Request & { user?: { id: string; role: Role; email: string } };
function auth(req: AuthedRequest, res: express.Response, next: express.NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) return res.status(401).json({ error: "Sign in required." });
  try {
    req.user = jwt.verify(header.slice(7), JWT_SECRET || "unsafe-development-secret") as { id: string; role: Role; email: string };
    next();
  } catch { return res.status(401).json({ error: "Session expired. Please sign in again." }); }
}
function admin(req: AuthedRequest, res: express.Response, next: express.NextFunction) {
  if (req.user?.role !== Role.ADMIN) return res.status(403).json({ error: "Admin access required." });
  next();
}
function slugify(s: string) { return s.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g,"-").replace(/(^-|-$)/g,"") || randomUUID().slice(0,8); }
function publicModel(m: any) {
  const { user, verificationCases, ...rest } = m;
  return { ...rest, email: undefined, ownerName: user?.displayName, verified: m.verificationStatus === VerificationStatus.VERIFIED };
}

app.get("/api/health", (_req,res) => res.json({ ok:true, service:"Glamour Luxe API" }));
app.get("/api/models", async (req,res) => {
  const q = String(req.query.q || "").trim();
  const language = String(req.query.language || "");
  const country = String(req.query.country || "");
  const status = String(req.query.status || "");
  const where: any = { age: { gte: 18 } };
  if (q) where.OR = [{ stageName:{contains:q,mode:"insensitive"}},{bio:{contains:q,mode:"insensitive"}},{country:{contains:q,mode:"insensitive"}}];
  if (language) where.languages = { has: language };
  if (country) where.country = { equals: country, mode:"insensitive" };
  if (status === "available") where.isAvailable = true;
  if (status === "featured") where.isFeatured = true;
  const models = await prisma.modelProfile.findMany({ where, include:{user:{select:{displayName:true}}}, orderBy:[{isFeatured:"desc"},{isVip:"desc"},{createdAt:"desc"}] });
  res.json(models.map(publicModel));
});
app.get("/api/models/:slug", async (req,res) => {
  const model = await prisma.modelProfile.findUnique({ where:{slug:req.params.slug}, include:{user:{select:{displayName:true}}} });
  if (!model || model.age < 18) return res.status(404).json({error:"Model not found."});
  res.json(publicModel(model));
});
app.post("/api/auth/register", async (req,res) => {
  const schema = z.object({email:z.string().email().max(200),password:z.string().min(10).max(100),displayName:z.string().min(2).max(80),role:z.enum(["USER","MODEL"]).default("USER"),isAdultConfirmed:z.literal(true)});
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({error:"Enter a valid email, display name, password (10+ characters), and confirm you are 18+."});
  const {email,password,displayName,role} = parsed.data;
  try {
    const user = await prisma.user.create({data:{email:email.toLowerCase(),passwordHash:await bcrypt.hash(password,12),displayName,role:role as Role,isAdultConfirmed:true}});
    if (role === "MODEL") {
      await prisma.modelProfile.create({data:{userId:user.id,slug:slugify(displayName)+"-"+randomUUID().slice(0,5),stageName:displayName,age:18,city:"Bangkok"}});
    }
    const token = jwt.sign({id:user.id,email:user.email,role:user.role},JWT_SECRET || "unsafe-development-secret",{expiresIn:"7d"});
    res.status(201).json({token,user:{id:user.id,email:user.email,displayName:user.displayName,role:user.role}});
  } catch { res.status(409).json({error:"An account with this email may already exist."}); }
});
app.post("/api/auth/login", async (req,res) => {
  const parsed = z.object({email:z.string().email(),password:z.string().min(1)}).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({error:"Enter your email and password."});
  const user = await prisma.user.findUnique({where:{email:parsed.data.email.toLowerCase()}});
  if (!user || !(await bcrypt.compare(parsed.data.password,user.passwordHash))) return res.status(401).json({error:"Email or password is incorrect."});
  const token = jwt.sign({id:user.id,email:user.email,role:user.role},JWT_SECRET || "unsafe-development-secret",{expiresIn:"7d"});
  res.json({token,user:{id:user.id,email:user.email,displayName:user.displayName,role:user.role}});
});
app.get("/api/me", auth, async (req:AuthedRequest,res) => {
  const user = await prisma.user.findUnique({where:{id:req.user!.id},include:{modelProfile:true}});
  if (!user) return res.status(404).json({error:"User not found."});
  res.json({id:user.id,email:user.email,displayName:user.displayName,role:user.role,modelProfile:user.modelProfile ? publicModel(user.modelProfile) : null});
});
app.put("/api/model/profile", auth, async (req:AuthedRequest,res) => {
  if (![Role.MODEL,Role.ADMIN].includes(req.user!.role)) return res.status(403).json({error:"Model account required."});
  const parsed = z.object({stageName:z.string().min(2).max(80),country:z.string().max(80).optional(),age:z.number().int().min(18).max(90),heightCm:z.number().int().min(120).max(230).optional(),languages:z.array(z.string().max(40)).max(12),categories:z.array(z.string().max(40)).max(12),bio:z.string().max(1200),photoUrl:z.string().url().max(500).or(z.literal("")),isAvailable:z.boolean()}).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({error:"Check the profile fields. Models must be 18+."});
  const profile = await prisma.modelProfile.findUnique({where:{userId:req.user!.id}});
  if (!profile) return res.status(404).json({error:"Model profile not found."});
  const updated = await prisma.modelProfile.update({where:{id:profile.id},data:parsed.data});
  res.json(updated);
});
app.post("/api/favorites/:modelId", auth, async (req:AuthedRequest,res) => {
  const modelId = req.params.modelId;
  const existing = await prisma.favorite.findUnique({where:{userId_modelId:{userId:req.user!.id,modelId}}});
  if (existing) await prisma.favorite.delete({where:{userId_modelId:{userId:req.user!.id,modelId}}});
  else await prisma.favorite.create({data:{userId:req.user!.id,modelId}});
  res.json({favorite:!existing});
});
app.get("/api/favorites", auth, async (req:AuthedRequest,res) => {
  const rows = await prisma.favorite.findMany({where:{userId:req.user!.id},include:{model:{include:{user:{select:{displayName:true}}}}}});
  res.json(rows.map(r=>publicModel(r.model)));
});

const storage = multer.diskStorage({
  destination: (_req,_file,cb) => cb(null,uploadDir),
  filename: (_req,file,cb) => cb(null,`${randomUUID()}${path.extname(file.originalname).toLowerCase()}`)
});
const upload = multer({storage,limits:{fileSize:Number(process.env.MAX_UPLOAD_MB || 8)*1024*1024},fileFilter:(_req,file,cb)=>{
  const ok = ["image/jpeg","image/png","application/pdf"].includes(file.mimetype);
  cb(ok ? null : new Error("Only JPG, PNG or PDF files are accepted."),ok);
}});
app.post("/api/verification", auth, upload.single("document"), async (req:AuthedRequest,res) => {
  if (![Role.MODEL,Role.ADMIN].includes(req.user!.role)) return res.status(403).json({error:"Model account required."});
  const profile = await prisma.modelProfile.findUnique({where:{userId:req.user!.id}});
  if (!profile) return res.status(404).json({error:"Model profile not found."});
  if (profile.age < 18) return res.status(403).json({error:"Only adults may apply."});
  const note = String(req.body.note || "").slice(0,500);
  const record = await prisma.verificationCase.create({data:{modelId:profile.id,status:VerificationStatus.PENDING,documentPath:req.file?.filename,documentName:req.file?.originalname,applicantNote:note}});
  await prisma.modelProfile.update({where:{id:profile.id},data:{verificationStatus:VerificationStatus.PENDING,verificationNote:null}});
  res.status(201).json({id:record.id,status:record.status,message:"Submitted for admin review."});
});
app.get("/api/model/payments", auth, async (req:AuthedRequest,res) => {
  const payments = await prisma.payment.findMany({where:{userId:req.user!.id},orderBy:{createdAt:"desc"}});
  res.json(payments.map(p=>({...p,amount:(p.amountCents/100).toFixed(2)})));
});
app.post("/api/payments/checkout", auth, async (req:AuthedRequest,res) => {
  if (!stripe) return res.status(503).json({error:"Payments are not configured yet. Add STRIPE_SECRET_KEY to the server .env."});
  const parsed = z.object({months:z.union([z.literal(1),z.literal(3),z.literal(6)])}).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({error:"Choose a valid VIP plan."});
  const model = await prisma.modelProfile.findUnique({where:{userId:req.user!.id}});
  if (!model) return res.status(400).json({error:"Only model accounts can buy a model VIP plan."});
  const prices:Record<number,number> = {1:4900,3:12900,6:22900};
  const months = parsed.data.months;
  const payment = await prisma.payment.create({data:{userId:req.user!.id,modelProfileId:model.id,planMonths:months,amountCents:prices[months],currency:"usd",status:PaymentStatus.PENDING}});
  try {
    const session = await stripe.checkout.sessions.create({
      mode:"payment",
      line_items:[{price_data:{currency:"usd",unit_amount:prices[months],product_data:{name:`Glamour Luxe VIP — ${months} month${months>1?"s":""}`,description:"VIP profile visibility subscription"}},quantity:1}],
      success_url:`${CLIENT_URL}/account?payment=success`,
      cancel_url:`${CLIENT_URL}/vip?payment=cancelled`,
      customer_email:req.user!.email,
      metadata:{paymentId:payment.id,userId:req.user!.id,months:String(months)}
    });
    await prisma.payment.update({where:{id:payment.id},data:{stripeSessionId:session.id}});
    res.json({url:session.url});
  } catch (e) {
    await prisma.payment.update({where:{id:payment.id},data:{status:PaymentStatus.FAILED}});
    console.error(e); res.status(502).json({error:"Could not create checkout session."});
  }
});
app.post("/api/bookings", auth, async (req:AuthedRequest,res) => {
  const parsed = z.object({modelId:z.string(),contactName:z.string().min(2).max(100),contactEmail:z.string().email(),message:z.string().min(10).max(1500)}).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({error:"Complete all booking inquiry fields."});
  const model = await prisma.modelProfile.findUnique({where:{id:parsed.data.modelId}});
  if (!model) return res.status(404).json({error:"Model not found."});
  const booking = await prisma.booking.create({data:{...parsed.data,clientId:req.user!.id}});
  res.status(201).json(booking);
});
app.get("/api/admin/overview", auth, admin, async (_req,res) => {
  const [models,users,pendingVerification,bookings,payments,vipModels,revenue] = await Promise.all([
    prisma.modelProfile.count(),prisma.user.count(),prisma.verificationCase.count({where:{status:VerificationStatus.PENDING}}),
    prisma.booking.count(),prisma.payment.count(),prisma.modelProfile.count({where:{isVip:true}}),
    prisma.payment.aggregate({where:{status:PaymentStatus.SUCCEEDED},_sum:{amountCents:true}})
  ]);
  res.json({models,users,pendingVerification,bookings,payments,vipModels,revenueCents:revenue._sum.amountCents || 0});
});
app.get("/api/admin/models", auth, admin, async (_req,res) => {
  const rows = await prisma.modelProfile.findMany({include:{user:{select:{id:true,email:true,displayName:true}}},orderBy:{createdAt:"desc"}});
  res.json(rows.map(m=>({...publicModel(m),user:m.user})));
});
app.patch("/api/admin/models/:id", auth, admin, async (req:AuthedRequest,res) => {
  const parsed = z.object({isFeatured:z.boolean().optional(),isAvailable:z.boolean().optional(),isVip:z.boolean().optional(),vipMonths:z.number().int().min(1).max(24).optional()}).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({error:"Invalid model update."});
  const data:any = {...parsed.data}; delete data.vipMonths;
  if (parsed.data.isVip === true && parsed.data.vipMonths) { const expiry = new Date(); expiry.setMonth(expiry.getMonth()+parsed.data.vipMonths); data.vipExpiresAt=expiry; }
  if (parsed.data.isVip === false) data.vipExpiresAt=null;
  const updated = await prisma.modelProfile.update({where:{id:req.params.id},data});
  await prisma.auditLog.create({data:{actorId:req.user!.id,action:"ADMIN_MODEL_UPDATE",entityType:"ModelProfile",entityId:updated.id,metadata:parsed.data}});
  res.json(updated);
});
app.get("/api/admin/verifications", auth, admin, async (_req,res) => {
  const cases = await prisma.verificationCase.findMany({include:{model:{include:{user:{select:{email:true,displayName:true}}}}},orderBy:{createdAt:"asc"}});
  res.json(cases.map(c=>({...c,documentPath:undefined,model:{...publicModel(c.model),user:c.model.user}})));
});
app.patch("/api/admin/verifications/:id", auth, admin, async (req:AuthedRequest,res) => {
  const parsed = z.object({decision:z.enum(["VERIFIED","REJECTED"]),adminNote:z.string().max(500).optional()}).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({error:"Choose VERIFIED or REJECTED."});
  const item = await prisma.verificationCase.findUnique({where:{id:req.params.id}});
  if (!item) return res.status(404).json({error:"Verification case not found."});
  const status = parsed.data.decision as VerificationStatus;
  await prisma.$transaction([
    prisma.verificationCase.update({where:{id:item.id},data:{status,adminNote:parsed.data.adminNote,reviewedById:req.user!.id,reviewedAt:new Date()}}),
    prisma.modelProfile.update({where:{id:item.modelId},data:{verificationStatus:status,verificationNote:parsed.data.adminNote,verifiedAt:status===VerificationStatus.VERIFIED?new Date():null}}),
    prisma.auditLog.create({data:{actorId:req.user!.id,action:`VERIFICATION_${status}`,entityType:"VerificationCase",entityId:item.id}})
  ]);
  res.json({ok:true,status});
});
app.get("/api/admin/verification-documents/:caseId", auth, admin, async (req,res) => {
  const item = await prisma.verificationCase.findUnique({where:{id:req.params.caseId}});
  if (!item?.documentPath) return res.status(404).json({error:"Document not found."});
  const filePath = path.join(uploadDir,item.documentPath);
  if (!filePath.startsWith(uploadDir)) return res.status(400).json({error:"Invalid file path."});
  if (!fs.existsSync(filePath)) return res.status(404).json({error:"File unavailable."});
  res.download(filePath,item.documentName || "verification-document");
});
app.get("/api/admin/bookings", auth, admin, async (_req,res) => {
  res.json(await prisma.booking.findMany({include:{client:{select:{email:true,displayName:true}},model:{select:{stageName:true,slug:true}}},orderBy:{createdAt:"desc"}}));
});
app.patch("/api/admin/bookings/:id", auth, admin, async (req,res) => {
  const parsed = z.object({status:z.nativeEnum(BookingStatus)}).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({error:"Invalid booking status."});
  res.json(await prisma.booking.update({where:{id:req.params.id},data:{status:parsed.data.status}}));
});
app.get("/api/admin/payments", auth, admin, async (_req,res) => {
  res.json(await prisma.payment.findMany({include:{user:{select:{email:true,displayName:true}}},orderBy:{createdAt:"desc"}}));
});
app.get("/api/admin/users", auth, admin, async (_req,res) => {
  res.json(await prisma.user.findMany({select:{id:true,email:true,displayName:true,role:true,createdAt:true,modelProfile:{select:{stageName:true,isVip:true,verificationStatus:true}}},orderBy:{createdAt:"desc"}}));
});
if (isProduction) {
  const webRoot = path.resolve(process.cwd(), "dist");
  app.use(express.static(webRoot));
  app.get("*", (req, res, next) => {
    if (req.path.startsWith("/api/")) return next();
    res.sendFile(path.join(webRoot, "index.html"), (err) => { if (err) next(err); });
  });
}

app.use((err:any,_req:express.Request,res:express.Response,_next:express.NextFunction) => {
  console.error(err);
  res.status(400).json({error:err.message || "Request failed."});
});
app.listen(PORT, "0.0.0.0", ()=>console.log(`Glamour Luxe server listening on ${PORT}`));
