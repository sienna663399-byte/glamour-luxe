import "dotenv/config";
import { PrismaClient, Role } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const email = process.env.ADMIN_EMAIL;
  const password = process.env.ADMIN_PASSWORD;
  if (!email || !password || password.includes("ChangeThis")) {
    throw new Error("Set ADMIN_EMAIL and a strong ADMIN_PASSWORD in .env before seeding.");
  }
  const passwordHash = await bcrypt.hash(password, 12);
  await prisma.user.upsert({
    where: { email },
    update: { passwordHash, role: Role.ADMIN },
    create: { email, passwordHash, role: Role.ADMIN, displayName: "Glamour Luxe Admin", isAdultConfirmed: true }
  });

  const demos = [
    {slug:"sophia",stageName:"Sophia",country:"Russian",age:24,heightCm:175,languages:["English","Russian","Thai"],categories:["Editorial","Fashion","Travel"],photoUrl:"https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=900&q=85",bio:"European model based in Bangkok. Available for professional fashion and editorial bookings.",isAvailable:true,isFeatured:true,isVip:true,verificationStatus:"VERIFIED" as const},
    {slug:"elise",stageName:"Elise",country:"French",age:22,heightCm:168,languages:["English","French","Thai"],categories:["Fashion","Beauty"],photoUrl:"https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=900&q=85",bio:"Fashion and beauty model with a polished editorial portfolio.",isAvailable:true,isFeatured:true,isVip:false,verificationStatus:"VERIFIED" as const},
    {slug:"anna",stageName:"Anna",country:"German",age:26,heightCm:172,languages:["English","German"],categories:["Editorial","Travel"],photoUrl:"https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=900&q=85",bio:"Editorial and lifestyle model available for selected projects.",isAvailable:false,isFeatured:true,isVip:true,verificationStatus:"PENDING" as const},
    {slug:"sofia",stageName:"Sofia",country:"Italian",age:23,heightCm:170,languages:["English","Italian","Thai"],categories:["Fashion","Beauty"],photoUrl:"https://images.unsplash.com/photo-1512316609839-ce289d3eba0a?auto=format&fit=crop&w=900&q=85",bio:"Fashion, beauty and lifestyle portfolio. Based in Bangkok.",isAvailable:true,isFeatured:false,isVip:false,verificationStatus:"VERIFIED" as const},
    {slug:"lina",stageName:"Lina",country:"Swedish",age:27,heightCm:176,languages:["English","Swedish"],categories:["Editorial","Fashion"],photoUrl:"https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&w=900&q=85",bio:"Professional fashion model focused on editorial and commercial work.",isAvailable:true,isFeatured:false,isVip:false,verificationStatus:"NOT_SUBMITTED" as const}
  ];
  for (const d of demos) {
    const email = `${d.slug}@demo.glamourluxe.local`;
    const user = await prisma.user.upsert({
      where:{email},
      update:{displayName:d.stageName},
      create:{email,passwordHash:await bcrypt.hash("DemoModel-ChangeMe-123!",12),displayName:d.stageName,role:Role.MODEL,isAdultConfirmed:true}
    });
    await prisma.modelProfile.upsert({
      where:{slug:d.slug},
      update:{...d,userId:user.id},
      create:{...d,userId:user.id}
    });
  }
  console.log("Seed complete. Demo model login password: DemoModel-ChangeMe-123! Change before production.");
}
main().finally(() => prisma.$disconnect());
